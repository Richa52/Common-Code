﻿Imports System
Imports System.Data
Imports System.Data.SqlClient


Public Class Form1
    Private _pph As Double
    Private ds As DataSet = New DataSet
    Private conn As SqlConnection = Nothing
    Private cmd As SqlCommand = Nothing
    Private totPPH As Double = 0
    Private nRow As DataGridViewRow = Nothing
    Private indRow As Integer = 0
    Private curFormula As String


    Private Sub LoadData()

        Dim sp As String = "usp_MaterialTypeSelect"

        Try
            If ds.Tables.Contains("MaterialType") Then

                ds.Tables("MaterialType").Clear()

            End If

            ds.Tables.Add("Recipe")
            With ds.Tables("Recipe")
                .Columns.Add("ID")
                .Columns.Add("Material")
                .Columns.Add("PPH")
            End With

            cboMatType.Items.Clear()
            conn.Open()
            cmd = New SqlCommand(sp, conn)
            cmd.CommandType = CommandType.StoredProcedure
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(ds, "MaterialType")

            conn.Close()
            cmd.Dispose()
            da.Dispose()

        Catch ex As Exception
            Throw New Exception("Error Loading data from SQL Server", ex)
        Finally

            If conn.State <> ConnectionState.Closed Then
                conn.Close()
            End If

        End Try

    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        conn = New SqlConnection(My.Settings.connStr)
        LoadData()

        With ds
            If .Tables("MaterialType").Rows.Count > 0 Then
                cboMatType.Items.Clear()
                For Each dr As DataRow In ds.Tables("MaterialType").Rows

                    cboMatType.Items.Add(dr("Name").ToString)

                Next
            End If

        End With

    End Sub


    Private Sub GetMaterialCategory()
        Dim sp As String = "usp_MaterialCategorySelect"
        Try
            dgvMaterial.DataSource = ""

            cboMatCat.Text = ""
            cboMatCat.Items.Clear()
            If ds.Tables.Contains("MaterialCategory") Then
                ds.Tables("MaterialCategory").Clear()
            End If

            cboMaterial.Items.Clear()
            If ds.Tables.Contains("Material") Then
                ds.Tables("Material").Clear()
            End If

            conn.Open()
            cmd = New SqlCommand(sp, conn)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@MatType", cboMatType.Text)
            cmd.Parameters(0).SqlDbType = SqlDbType.VarChar

            Dim da As New SqlDataAdapter(cmd)
            da.Fill(ds, "MaterialCategory")

            conn.Close()
            cmd.Dispose()
            da.Dispose()

            With ds
                If .Tables("MaterialCategory").Rows.Count > 0 Then
                    For Each dr As DataRow In ds.Tables("MaterialCategory").Rows
                        cboMatCat.Items.Add(dr("Name").ToString)
                    Next

                End If
            End With

        Catch ex As Exception
            Throw New Exception("Error Loading data from SQL Server", ex)
        Finally
            If conn.State <> ConnectionState.Closed Then
                conn.Close()
            End If
        End Try

    End Sub

    ' List of current materials of type Formula
    Private Sub SetCurFormulas()
        If cboMatType.Text = "Formula" Then

            If ds.Tables.Contains("curFormulas") = True Then
                ds.Tables.Remove("curFormulas")
            End If
            ds.Tables.Add("curFormulas")
            With ds.Tables("curFormulas")
                .Columns.Add("ID")
                .Columns.Add("Category")
                .Columns.Add("Name")
                .Columns.Add("Price")

                For Each dr As DataRow In ds.Tables("Material").Rows
                    Dim obj() As Object = {dr("ID"), dr("Category"), dr("Material"), dr("Price")}
                    .LoadDataRow(obj, True)
                    .EndLoadData()
                Next

            End With

        End If
    End Sub

    Private Sub GetMaterialsByCategory(ByVal cat As String)

        Dim sp As String = "usp_MaterialSelect"
        cboMaterial.Items.Clear()
        cboMaterial.Text = ""

        If ds.Tables.Contains("Material") Then
            ds.Tables("Material").Clear()
        End If

        Try
            ' Get data from IndRecipeTest.mdf
            conn.Open()
            cmd = New SqlCommand(sp, conn)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@MatCat", cat)
            cmd.Parameters(0).SqlDbType = SqlDbType.VarChar

            Dim da As New SqlDataAdapter(cmd)
            da.Fill(ds, "Material")

            conn.Close()    ' Clean up after yourself
            cmd.Dispose()
            da.Dispose()

            ' load ComboBox values
            With ds
                If .Tables("Material").Rows.Count > 0 Then
                    For Each dr As DataRow In ds.Tables("Material").Rows
                        cboMaterial.Items.Add(dr("Material").ToString)
                    Next
                End If
            End With

            SetCurFormulas()

            ' Load DataGridView datasource
            dgvMaterial.DataSource = ""
            dgvMaterial.DataSource = ds.Tables("Material")

            FormatDGVChemical()

        Catch ex As Exception
            Throw New Exception("Error Loading data from SQL Server", ex)
        Finally
            If conn.State <> ConnectionState.Closed Then
                conn.Close()
            End If
        End Try

    End Sub

    Private Sub FormatDGVRecipe()

        With dgvRecipe

            .Columns(0).Visible = False
            .Columns(1).AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill
            .Columns(2).AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells
            .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            .Columns(2).DefaultCellStyle.Format = "0.000"

        End With
    End Sub

    Private Sub FormatDGVChemical()
        ' Format the DataGridView
        With dgvMaterial
            .Columns(0).Visible = False
            .Columns(1).AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells
            .Columns(2).AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill
            .Columns(3).Visible = False
        End With
    End Sub

    Private Sub GetRecipe()
        Try

            If ds.Tables.Contains("Recipe") Then
                ds.Tables.Remove("Recipe")
            End If

            conn.Open()
            cmd = New SqlCommand("usp_FormulaBOMSelect", conn)
            cmd.CommandType = CommandType.StoredProcedure

            With cmd
                .Parameters.AddWithValue("@Form", curFormula)
                .Parameters(0).SqlDbType = SqlDbType.VarChar
            End With

            Dim da As New SqlDataAdapter(cmd)
            da.Fill(ds, "Recipe")

            dgvRecipe.DataSource = Nothing
            dgvRecipe.DataSource = ds.Tables("Recipe")
            FormatDGVRecipe()

            lblCurFormula.Text = curFormula

        Catch ex As Exception
            MsgBox("OOooops  - " & ex.ToString, MsgBoxStyle.OkOnly, "ERROR")
        Finally
            conn.Close()
            cmd.Dispose()

        End Try
    End Sub

    Private Sub InsertNewMaterial()
        If (cboMatCat.Text <> "") And (cboMaterial.Text <> "") And _
                            (IsNumeric(txtPrice.Text) = True) Then

            Dim price As Double = 0
            If Double.TryParse(txtPrice.Text, price) = False Then
                MsgBox("Invalid Price was entered...", MsgBoxStyle.OkOnly)
                txtPrice.Select()
                Exit Sub
            Else

                Dim res As Integer = AddMaterial(cboMatCat.Text, cboMaterial.Text, price)

                If res > 0 Then

                    cboMaterial.Items.Add(cboMaterial.Text)

                    GetMaterialsByCategory(cboMatCat.Text)

                End If
            End If
        End If
    End Sub

    ' set up a BOM Table to mimic the FormulaBOM databse table
    Private Sub SetBOM()
        If ds.Tables.Contains("BOM") = False Then
            Dim dt As DataTable = New DataTable("BOM")
            dt.TableName = "BOM"

            dt.Columns.Add("Mat_ID")
            dt.Columns.Add("PPH")
            ds.Tables.Add(dt)
        Else
            ds.Tables("BOM").Clear()
        End If

        For Each dr As DataGridViewRow In dgvRecipe.Rows

            If dr.Index = dgvRecipe.Rows.Count - 1 Then
                Exit For
            End If

            Debug.WriteLine("Mat_ID = " & dr.Cells("ID").Value & ", " & dr.Cells(2).Value)

            Dim pph As Double = 0
            If Double.TryParse(dr.Cells("PPH").Value, pph) = True Then

                Dim obj() As Object = {dr.Cells("ID").Value, pph}
                ds.Tables("BOM").Rows.Add(obj)
            End If

        Next
    End Sub

    Private Function AddMaterial(ByVal matcat As String, ByVal name As String, ByVal price As Double) As Integer

        Dim res As Integer = 0       ' Return variable

        Try
            conn.Open()
            cmd = New SqlCommand("usp_MaterialInsert", conn)
            cmd.CommandType = CommandType.StoredProcedure
            With cmd
                .Parameters.AddWithValue("@MatCat", matcat)
                .Parameters(0).SqlDbType = SqlDbType.VarChar
                .Parameters.AddWithValue("@Name", name)
                .Parameters(1).SqlDbType = SqlDbType.VarChar
                .Parameters.AddWithValue("@Price", price)
                .Parameters(2).SqlDbType = SqlDbType.Money
            End With

            res = cmd.ExecuteScalar

        Catch ex As Exception
            ' TODO: Error Handling
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return res

    End Function

    ' -------------------------------------------------------------------------
    ' This is where we use the TVP_BOM User-Defined Type
    '--------------------------------------------------------------------------
    Private Sub InsertFormulaBOM(ByVal formID As Integer)

        If dgvRecipe.DataSource IsNot Nothing Then

            ' Set up a BOM Table to pass to the database
            ' BOM Table must match TVP_BOM UDT
            SetBOM()

            Try
                conn.Open()     ' Open connection
                cmd = New SqlCommand("usp_FormulaBOMInsert", conn)  ' Set Command
                cmd.CommandType = CommandType.StoredProcedure

                ' Set parameters
                With cmd
                    ' Formula ID parameter
                    .Parameters.AddWithValue("@Form_ID", formID)
                    .Parameters(0).SqlDbType = SqlDbType.VarChar
                    ' BOM Table parameter
                    .Parameters.AddWithValue("@BOM", ds.Tables("BOM"))
                    .Parameters(1).SqlDbType = SqlDbType.Structured     ' Note Structured

                End With

                cmd.ExecuteNonQuery()

                conn.Close()
                cmd.Dispose()

                GetMaterialsByCategory(cboMatCat.Text)

            Catch ex As Exception
                MsgBox("Ooops!  - " & ex.ToString, MsgBoxStyle.OkOnly, "ERROR")
            Finally
                conn.Close()
                cmd.Dispose()
            End Try
        End If
    End Sub
    '--------------------------------------------------------------------------
    '--------------------------------------------------------------------------



    Private Sub cboMatType_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboMatType.SelectedValueChanged

        GetMaterialCategory()

    End Sub

    Private Sub cboMatCat_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboMatCat.SelectedValueChanged

        GetMaterialsByCategory(cboMatCat.Text)

    End Sub

    Private Sub cboMaterial_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboMaterial.SelectedValueChanged

        If cboMatType.Text = "Formula" Then
            curFormula = cboMaterial.Text
        End If

    End Sub

    Private Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd.Click

        If Not dgvMaterial.SelectedRows.Count = 0 Then
            _pph = CDbl(InputBox("Enter PPH"))

            Dim dr As DataGridViewRow = dgvMaterial.SelectedRows(0)

            Dim obj() As Object = {dr.Cells("ID").Value, dr.Cells("Material").Value, _pph.ToString("0.000")}

            ds.Tables("Recipe").Rows.Add(obj)

            dgvRecipe.DataSource = ""
            dgvRecipe.DataSource = ds.Tables("Recipe")

            FormatDGVRecipe()

        End If
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click

        InsertNewMaterial()
        btnAdd.Enabled = True

    End Sub

    Private Sub btnShowRecipe_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowRecipe.Click

        dgvRecipe.DataSource = Nothing
        GetRecipe()

        If ds.Tables("Recipe").Rows.Count > 0 Then
            btnAdd.Enabled = False
        Else
            btnAdd.Enabled = True
        End If

    End Sub

    Private Sub btnEnter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEnter.Click

        If curFormula <> "" Then


            With ds.Tables("curFormulas")
                For Each dr As DataRow In .Rows
                    ' If the formula name exists...
                    If dr("Name") = curFormula Then
                        ' Insert a new FormulaBOM
                        InsertFormulaBOM(dr("ID"))
                        Exit Sub
                    End If
                Next
            End With

        End If

    End Sub

    Private Sub btnRemove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRemove.Click

        ' TODO: Add remove recipe row functionality
        
    End Sub

   
End Class
